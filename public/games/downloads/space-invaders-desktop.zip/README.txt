Extract this ZIP, open a terminal in the extracted folder, and run:

java -cp space-invaders.jar InvadersApplication

Requires Java 21 or newer and a desktop environment.
