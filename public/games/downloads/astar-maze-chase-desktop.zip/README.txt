Extract this ZIP, open a terminal in the extracted folder, and run:

java -cp astar-maze-chase.jar AStarMaze

Requires Java 8 or newer and a desktop environment.
